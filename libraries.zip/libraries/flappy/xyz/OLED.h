// Size of 128x64 OLED screen
#define MAXX 128
#define MAXY 64
#define MAXROWS 8

#define SDAWIRE 5
#define SCLWIRE 4

// Co-ord of centre of screen
#define CENX (MAXX / 2)
#define CENY (MAXY / 2)

#define LEFTBAT 0
#define RIGHTBAT (MAXX - 2)

#define PLAYER 1  // Player seves ball
#define AI 2      // AI serves ball

// AI actions when ball on player's side of net
#define STAY 0    // AI does not move
#define JIGGLE 1  // AI moves up and down
#define SHADOW 2  // AI matches player movement
#define CENTRE 3  // AI moves towards centre of screen

// SSD1306 command bytes
#define SSD1306_SETCONTRAST 0x81
#define SSD1306_DISPLAYALLON_RESUME 0xA4
#define SSD1306_DISPLAYALLON 0xA5
#define SSD1306_NORMALDISPLAY 0xA6
#define SSD1306_INVERTDISPLAY 0xA7
#define SSD1306_DISPLAYOFF 0xAE
#define SSD1306_DISPLAYON 0xAF

#define SSD1306_SETDISPLAYOFFSET 0xD3
#define SSD1306_SETCOMPINS 0xDA

#define SSD1306_SETVCOMDETECT 0xDB

#define SSD1306_SETDISPLAYCLOCKDIV 0xD5
#define SSD1306_SETPRECHARGE 0xD9

#define SSD1306_SETMULTIPLEX 0xA8

#define SSD1306_SETLOWCOLUMN 0x00
#define SSD1306_SETHIGHCOLUMN 0x10

#define SSD1306_SETSTARTLINE 0x40

#define SSD1306_MEMORYMODE 0x20
#define SSD1306_COLUMNADDR 0x21
#define SSD1306_PAGEADDR   0x22

#define SSD1306_COMSCANINC 0xC0
#define SSD1306_COMSCANDEC 0xC8

#define SSD1306_SEGREMAP 0xA0

#define SSD1306_CHARGEPUMP 0x8D

// The frame buffer, 1024 bytes
unsigned char Frame[MAXROWS][MAXX];
int Aibaty;  // AI's bat position (Y co-ord)
int Pscore;
int Ascore;
int AIstate = SHADOW;
int AIfatigue;
#define JOYMAX 662
#define JOYMIN 362

#define offset 0x00    // SDD1306                      // offset=0 for SSD1306 controller
//#define offset 0x02    // SH1106                       // offset=2 for SH1106 controller
#define OLED_address  0x3c                             // all the OLED's I have seen have this address

/* clrFrame --- clear the entire frame to white */

void clrFrame (void);

/* greyFrame --- clear entire frame to checkerboard pattern */

void greyFrame (void);

/* textRoundRect --- draw a rounded rectangle containing text message */

void textRoundRect (const char *str);

/* textRoundRect2 --- draw a rounded rectangle containing two text messages */

void textRoundRect2 (const char *str1, const char *str2);

/* setText --- draw text into buffer using predefined font */

void setText (int x, const int y, const char *str);

/* setLine --- draw a line between any two absolute co-ords */

void setLine (int x1, int y1, int x2, int y2);

/* circle --- draw a circle using Michener's algorithm */

void circle (int x0, int y0, int r, int ec, int fc);

static void cpts (int x0, int y0, int x, int y, int ec, int fc);

/* drawRoundRect --- draw a rounded rectangle */

void drawRoundRect (int x0, int y0, int x1, int y1, int r);

/* fillRoundRect --- fill a rounded rectangle */

void fillRoundRect (int x0, int y0, int x1, int y1, int r);

/* drawSplitCircle --- draw a split circle with edge and fill colours */

void drawSplitCircle (int x0, int y0, int x1, int y1, int r, int ec, int fc);

/* cfill --- draw horizontal lines to fill a circle */

static void splitcfill (int x0, int y0, int x1, int y1, int x, int y, int fc);

/* splitcpts8 --- draw eight pixels to form the edge of a split circle */

static void splitcpts8 (int x0, int y0, int x1, int y1, int x, int y, int ec);

/* splitcpts4 --- draw four pixels to form the edge of a split circle */

static void splitcpts4 (int x0, int y0, int x1, int y1, int x, int y, int ec);

/* setVline --- draw vertical line */

void setVline (unsigned int x, unsigned int y1, unsigned int y2);

/* clrVline --- draw vertical line */

void clrVline (unsigned int x, unsigned int y1, unsigned int y2);

//* setHline --- set pixels in a horizontal line */

void setHline (unsigned int x1, unsigned int x2, unsigned int y);

/* clrHline --- clear pixels in a horizontal line */

void clrHline (unsigned int x1, unsigned int x2, unsigned int y);

/* setRect --- set pixels in a (non-filled) rectangle */

void setRect (int x1, int y1, int x2, int y2);

/* fillRect --- set pixels in a filled rectangle */

void fillRect (int x1, int y1, int x2, int y2, int ec, int fc);

/* setPixel --- set a single pixel */

void setPixel (unsigned int x, unsigned int y);

/* clrPixel --- clear a single pixel */

void clrPixel (unsigned int x, unsigned int y);

/* updscreen --- update the physical screen from the buffer */

void updscreen (void);

/* oled1202_begin --- initialise the 128x64 OLED */

void oled_begin (void);

/* oledData --- send a data byte to the OLED by fast hardware SPI */

inline void oledData (unsigned char d);

/* oledCmd --- send a command byte to the OLED by fast hardware SPI */

inline void oledCmd (unsigned char d);

