int    joystick_xmax = 1023;
float  joystick_xmult = 1;
int    joystick_ymax = 1023;
float  joystick_ymult = 1;
int    joystick_x = 0;
int    joystick_y = 0;

static void Joystick_Calibrate();
static unsigned int Joystick_Get_X();
static unsigned int Joystick_Get_Y();
